<?php
/*
 * @package wanfeng
 * @author 晚风
 * @version 1.0.0
 * @link https://wfvp.cc
 */
$this->need('header.php');?>
 
	<div class="wrapper mt-4">
	   
	<div class="cont-txt">
	    <div class="htmleaf-container">
		<header id="first" class="paralasic" data-paralasic="0.5" style="background-image: url('<?php echo $this->fields->dbbjt();?>')">
		    <h1 class="post_title"><?php $this->title() ?></h1>
		</header>
				</div>

		  <span class="post_text">
		    <?php $this->content(); ?>
		
 
		  </span>
		 
		  
 </div>   
<i class="fa fa-tags" aria-hidden="true"></i> :<?php printTag($this); ?>


<?php include('comments.php'); ?>
</div>  
 <?php $this->need('footer.php'); ?>