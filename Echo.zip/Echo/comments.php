<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="comments">
  <!-- Default -->
  <?php function threadedComments($comments, $options) {
    $commentClass = '';
      if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
          $commentClass .= ' comment-by-author';
        } else {
          $commentClass .= ' comment-by-user';
      }
    }
    $commentLevelClass = $comments->levels > 0 ? ' comment-child' : ' comment-parent';
  ?>
    <li itemscope itemtype="http://schema.org/UserComments" id="comment-<?php $comments->theId(); ?>"  class="comment-body<?php
      if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
      } else {
        echo ' comment-parent';
      }
      $comments->alt(' comment-odd', ' comment-even');
      echo $commentClass;
    ?> comments">
        
     <li id="comment-6565" class="comment-body comment-parent comment-odd">
            <div id="div-comment-6565" class="comment-body">

                <a class="pull-left thumb-sm" rel="nofollow">
                    <span itemprop="image"><?php $number=$comments->mail;
if(preg_match('|^[1-9]\d{4,11}@qq\.com$|i',$number)){
echo '<img src="https://q2.qlogo.cn/headimg_dl? bs='.$number.'&dst_uin='.$number.'&dst_uin='.$number.'&;dst_uin='.$number.'&spec=100&url_enc=0&referer=bu_interface&term_type=PC" alt="<?php echo $comments->author; ?>" height="50" width="50" class="avatar avatar-50 photo"/>'; 
}else{
echo '<img src="https://www.icnal.com/sjtx/api.php" height="50" width="50" class="avatar avatar-50 photo"/>';
}
?></span>               </a>
                <div class="m-b m-l-xxl">
                    <div class="comment-meta">
            <span class="comment-author vcard">
              <b class="fn"><?php $comments->author(); ?></b>              </span>
                        <div class="comment-metadata">
                            <time class="format_time text-muted text-xs block m-t-xs" pubdate="pubdate" datetime="<?php $comments->dateWord(); ?>"><?php $comments->dateWord(); ?></time>
                        </div>
                    </div>
                    <!--回复内容-->
                    <div class="comment-content m-t-sm">
                        <span class="comment-author-at"><b></b></span><span class="comment-content-true">
                            <p><?php $comments->content(); ?></p>                        </span>
                    </div>
                    <!--回复按钮-->
                    <div class="comment-reply m-t-sm">
                       <?php $comments->reply(); ?>     </div>
                </div>

            </div>
            <!-- 单条评论者信息及内容 -->
             <!-- 是否嵌套评论判断结束 -->
        </li>
  
    
    <?php if ($comments->children) { ?>
      <div class="comment-children">
        <?php $comments->threadedComments($options); ?>
      </div>
    <?php } ?>
    </li>
  <?php } ?>

  <?php $this->comments()->to($comments); ?>

  <?php if($this->allow('comment')): ?>

      <div id="<?php $this->respondId(); ?>" class="respond">
        <div class="comments-content">
         
   
      <?php if ($comments->have()): ?>
      <div id="msgBox">
        <div class="list">
        <h3 style="margin-top: 30px;"><span>大家在说</span></h3></div></div>
        
        <?php $comments->listComments(); ?>
        <?php $comments->pageNav('&laquo;', '&raquo;', 5, '...', array('wrapTag' => 'ul', 'wrapClass' => 'page-change', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'active', 'prevClass' => 'prev', 'nextClass' => 'next')); ?>

      <?php endif;
  endif; ?>
  <br>
   <!-- Comment Form -->
   <!-- 判断设置是否允许对当前文章进行评论 -->
<?php if($this->allow('comment')): ?>
          <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" class="comment-form" role="form">
            <h3 class="response"><?php _e('留言板'); ?></h3>
            <?php if($this->user->hasLogin()): ?>
            <p><?php _e('你好，'); ?><a style="color:#000" href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>。<?php _e('不是？'); ?><a style="color:#000" href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?></a></p>
              <!-- 若当前用户未登录 -->
            <?php else: ?>
        	
<div class="container">

					<section class="content">
						<span class="input input--hoshi">
				
					<input name="author" class="input__field input__field--hoshi" type="text" id="input-4" value="<?php $this->remember('author'); ?>" required>
					<label class="input__label input__label--hoshi input__label--hoshi-color-1" for="input-4">
						<span class="input__label-content input__label-content--hoshi">称呼</span>
					</label>
				</span>
				<span class="input input--hoshi">
				    <input type="email" name="mail" id="input-5"  class="input__field input__field--hoshi" value="<?php $this->remember('mail'); ?>" <?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?>>
              
					<label class="input__label input__label--hoshi input__label--hoshi-color-2" for="input-5">
						<span class="input__label-content input__label-content--hoshi">邮箱</span>
					</label>
				</span>
				<span class="input input--hoshi url-field">
				    <input class="input__field input__field--hoshi" type="url" name="url" id="input-6" class="text"  value="<?php $this->remember('url'); ?>" <?php if ($this->options->commentsRequireURL): ?> required<?php endif; ?>>
            
					<label class="input__label input__label--hoshi input__label--hoshi-color-4" for="input-6">
						<span class="input__label-content input__label-content--hoshi">网址</span>
					</label>
				</span>
				
			</section>
	</div>
		 <?php endif; ?>
            <!-- 输入要回复的内容 -->
             <!-- 输入要回复的内容 -->
             
      <span class="input input--hoshi">
     <textarea class="input__field input__field--hoshi OwO-textarea" rows="10" cols="50" name="text" d="input-6" placeholder="<?php _e('请填写您的内容。'); ?>" required></textarea>
    	<label class="input__label input__label--hoshi input__label--hoshi-color-3" for="input-6">
					
					</label>
				</span>
			<div class="OwO"></div>
	 <div class="grid">
  <?php $comments->cancelReply(); ?> <button class="buttonsubmit"><span type="submit" class="submit" >发表</span></button>		</div>


    </form>

	
           
	
  </div></div> </div></div>
  <?php endif; ?>
  <br>