<?php
function themeConfig($form) {
 $touxiang = new Typecho_Widget_Helper_Form_Element_Text('touxiang', NULL, NULL, _t('头像链接'), _t('如:https://q1.qlogo.cn/g?b=qq&nk=171394827&s=640'));
 $form->addInput($touxiang);
 $tongji = new Typecho_Widget_Helper_Form_Element_Text('tongji', NULL, NULL, _t('顶部统计'), _t('如：统计代码'));
 $form->addInput($tongji);
 $zzxx = new Typecho_Widget_Helper_Form_Element_Text('zzxx', NULL, NULL, _t('作者信息'), _t('如：作者信息'));
 $form->addInput($zzxx);

}
function themeFields($layout) {
        $dbbjt = new Typecho_Widget_Helper_Form_Element_Text('dbbjt', NULL, NULL, _t('文章标题背景图'), _t('文章标题显示的背景图,没有则空白（图书的链接也是这个）'));
        $layout->addItem($dbbjt);
    }

/*标签tag*/
function printTag($that) { ?>
        <?php if (count($that->tags) > 0): ?>
            <?php foreach( $that->tags as $tags): ?>
            <a href="<?php print($tags['permalink']) ?>" class="btn btn-primary btn-sm"><span><?php print($tags['name']) ?></span></a>
            <?php endforeach;?>
        <?php else: ?>
            <a class="hover-target"><span>无标签</span></a>
        <?php endif;?>
<?php }

/*文章阅读*/
function get_post_view($archive)
{
    $cid    = $archive->cid;
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 0;');
        echo 0;
        return;
    }
    $row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
    if ($archive->is('single')) {
 $views = Typecho_Cookie::get('extend_contents_views');
        if(empty($views)){
            $views = array();
        }else{
            $views = explode(',', $views);
        }
if(!in_array($cid,$views)){
       $db->query($db->update('table.contents')->rows(array('views' => (int) $row['views'] + 1))->where('cid = ?', $cid));
array_push($views, $cid);
            $views = implode(',', $views);
            Typecho_Cookie::set('extend_contents_views', $views); //记录查看cookie
        }
    }
    echo $row['views'];
}
/*字数统计*/
function  art_count ($cid){
$db=Typecho_Db::get ();
$rs=$db->fetchRow ($db->select ('table.contents.text')->from ('table.contents')->where ('table.contents.cid=?',$cid)->order ('table.contents.cid',Typecho_Db::SORT_ASC)->limit (1));
echo mb_strlen($rs['text'], 'UTF-8');
}
?>

