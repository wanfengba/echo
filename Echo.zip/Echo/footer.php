	</div>
   <?php $this->footer(); ?>
<div class="footer">
		  <div>
		    <ul>
		      <li><span><?php $this->options->tongji();?></span></li>
		      <li><span><?php $this->options->zzxx(); ?></span></li>
		      <li><span>footer 2</span></li>
		      <li><span>footerasd tre</span></li>
		    </ul>
		  </div>
		</div>
		<!--评论表情-->
		<script src="<?php $this->options->themeUrl('dist/OwO.min.js'); ?>"></script>
		<script> 
		var OwO_demo = new OwO({
		logo: 'OωO表情',
		container: document.getElementsByClassName('OwO')[0],
		target: document.getElementsByClassName('OwO-textarea')[0],
		api: '<?php $this->options->themeUrl('dist/OwO.json'); ?>',
		position: 'down',
		width: '100%',
		maxHeight: '250px'
		});
		</script>
	<!--导航-->
	<script src="<?php $this->options->themeUrl('js/jquery-1.11.0.min.js'); ?>" type="text/javascript"></script>
	<script src="https://cdn.bootcss.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
	<script  src="<?php $this->options->themeUrl('js/header.js'); ?>"></script>
		<!--导航-->
<!--加载更多-->
<script src="<?php $this->options->themeUrl('js/jquery.simpleLoadMore.js'); ?>"></script>
<script>
	    $('.some-list').simpleLoadMore({
	      item: 'div.item',
	      count: 5
	    });
	</script>
<!--加载更多-->
<!--评论-->
		<script src="<?php $this->options->themeUrl('js/classie.js'); ?>"></script>
		<script>
			(function() {
				// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
				if (!String.prototype.trim) {
					(function() {
						// Make sure we trim BOM and NBSP
						var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
						String.prototype.trim = function() {
							return this.replace(rtrim, '');
						};
					})();
				}

				[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
					// in case the input is already filled..
					if( inputEl.value.trim() !== '' ) {
						classie.add( inputEl.parentNode, 'input--filled' );
					}

					// events:
					inputEl.addEventListener( 'focus', onInputFocus );
					inputEl.addEventListener( 'blur', onInputBlur );
				} );

				function onInputFocus( ev ) {
					classie.add( ev.target.parentNode, 'input--filled' );
				}

				function onInputBlur( ev ) {
					if( ev.target.value.trim() === '' ) {
						classie.remove( ev.target.parentNode, 'input--filled' );
					}
				}
			})();
		</script>
<!--图片-->
