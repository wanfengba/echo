<!--
 * 
 *
 * @package Eliauk
 * @author 晚风
 * @version 1.0.0
 * @link https://wfvp.cc
 * 
 *大佬说我的代码很乱，不要抄我代码，自己写

-->
<!DOCTYPE html>

<html>
<head>
    <?php $this->header(); ?>
   
    
  
    <title><?php $this->archiveTitle(array(
        'category'  =>  _t('分类 %s 下的文章'),
        'search'    =>  _t('包含关键字 %s 的文章'),
        'tag'       =>  _t('标签 %s 下的文章'),
        'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>
        
    <link href="<?php $this->options->themeUrl('style.css'); ?>"rel="stylesheet">
    <link href="<?php $this->options->themeUrl('css/font-awesome.min.css'); ?>"rel="stylesheet">
    <link href="<?php $this->options->themeUrl('css/font-awesome.css'); ?>"rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('dist/OwO.min.css'); ?>">
    <meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

   	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<!-- QQCard BEGIN -->
    <meta itemprop="name" content="<?php $this->options->title(); ?>">
    <meta itemprop="image" content="<?php $this->options->qqLogo(); ?>">
    <meta name="description" itemprop="description" content="<?php $this->options->description() ?>">
    <!-- QQCard END -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	

    </head>
<!-- 页眉 -->
<nav class="navbar navbar-expand-md navbar-dark bg-dark navbar-offcanvas">
  <div class="container-fluid">
      <a class="navbar-brand" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>
      <button class="navbar-toggler navbar-toggler-right navbar-icon" type="button" data-toggle="collapse" data-target="#navbar-mobile" aria-controls="navbar-mobile" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon-bar bar1"></span>
          <span class="icon-bar bar2"></span>
          <span class="icon-bar bar3"></span>
      </button>
      <div class="navbar-collapse collapse ml-auto" id="navbar-mobile">
          <ul class="navbar-nav ml-auto">
              <li class="nav-image">
                  <img src="<?php $this->options->touxiang(); ?>" alt="<?php $this->options->title() ?>" style="border-radius: 3px;">
              </li>
              <li class="nav-item">
                  <li class="nav-item">
                <a href="<?php $this->options->siteUrl(); ?>" class="nav-link">首页</a>
                </li>
                <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?> </li>
<?php while($pages->next()): ?>
              <li class="nav-item">
                <a<?php if($this->is('page', $pages->slug)): ?> class="nav-link"<?php endif; ?> href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
                </li>
<?php endwhile; ?>

                
             
             
          </ul>
      </div>
  </div>
</nav>

                   
                   

     
			
			
			
			  