<?php
/**
 * 本主题基于枯木逢春创做
 * 念念不忘，必有回响
 * @package Echo
 * @author 枯木逢春
 * @version 1.0.1
 * @link https://wfvp.cc
 */
$this->need('header.php');?>

	
		 

			<div class="wrapper mt-4">
		<!--文章卡片-->
		<div class="some-list">
		<?php while($this->next()): ?>
    <div class="post"> 
		<div class="ph-item item">

        <div class="ph-col-12 item">
          <div class="ph-picture" style="background-image: url(<?php echo $this->fields->dbbjt();?>);"></div>
        </div>

        <div class="ph-col-2">
          <div class="ph-avatar"><img src="https://q1.qlogo.cn/g?b=qq&amp;nk=171394827&amp;s=640" width="44px" height="44px" alt="irils's avatar"></div>
        </div>

        <div>
          <div class="ph-row">
            <div class="author empty"><?php $this->author(); ?></div>
            <div class="category empty"><?php get_post_view($this) ?> 人阅读丨共<?php echo art_count($this->cid); ?>字符</div>
            <div class="date empty"><?php $this->date('Y丨M丨d'); ?></div>
          </div>
        </div>

        <div class="ph-col-12">
          <div class="ph-row">
            <a href="<?php $this->permalink() ?>"><div class="ph-col-10 big"><?php $this->title() ?></div></a>
            
            <div class="content"><?php $this->summary(); ?></div>
          </div>
        </div>

      </div>
		  </div>
		
		  
<?php endwhile; ?>
	
		
		
		
		
		
		
		  </div>
</div></div>
<?php $this->need('footer.php'); ?>
